# WebOps product proof

Show one real website repair from broken visitor route to a working services page. Use actual completed live-run evidence, without presenting the capture as agent execution in real time.

Output: 1920 × 1080, 30 fps. Five contiguous scenes paced to measured Siren narration. First four scenes are full-frame Chrome captures at a fixed scale of 1. The final Kujo bumper has its complete logo, wordmark, call to action and URL visible on frame one.

The sequence follows the planning shot list: original website and failed link; connected floor stations; broken link and image alternative repair; before/after proof and working candidate destination; Kujo.

Reuse the original music bed at0.12 gain, original K SVG and Departure Mono. Narration remains the primary audio. No new external media, subtitles, scene labels, overlays, startup gray frames, entrance zooms or blank bumper frames.

Inspect the first frame, each scene midpoint, every cut at ±0.15 seconds, and the final frame. Scan all frames for black, blank white, startup gray and isolated flash candidates. Measure audio without claiming listening. Preserve unresolved perceptual review as REVIEW_INCOMPLETE.
