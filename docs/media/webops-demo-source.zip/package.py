from pathlib import Path
import subprocess,json,hashlib,shutil,zipfile
w=Path('.runtime/demo');out=Path('docs/media');out.mkdir(parents=True,exist_ok=True);draft=w/'output/draft.mp4';plan=json.loads((w/'plan.json').read_text())
for mobile in [False,True]:
 dest=out/('webops-factory-demo-mobile.mp4' if mobile else 'webops-factory-demo.mp4')
 args=['ffmpeg','-v','error','-y','-i',str(draft)]+(['-vf','scale=1280:720','-c:v','libx264','-preset','fast','-crf','23','-profile:v','main','-level','3.1','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k'] if mobile else ['-c','copy'])+['-movflags','+faststart',str(dest)]
 subprocess.run(args,check=True);subprocess.run(['ffmpeg','-v','error','-i',str(dest),'-f','null','-'],check=True)
r=subprocess.run(['ffmpeg','-hide_banner','-i',str(draft),'-af','loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json','-f','null','-'],capture_output=True,text=True,check=True);measure=json.JSONDecoder().raw_decode(r.stderr[r.stderr.rindex('{'):])[0];(w/'review/audio.json').write_text(json.dumps(measure,indent=2))
subprocess.run(['python3',str(w/'check-frames.py'),str(draft),str(w/'review/frame-scan.json')],check=True)
for n,s in enumerate(plan['scenes'][1:]):subprocess.run(['ffmpeg','-v','error','-y','-ss',str(max(0,s['start']-.15)),'-i',str(draft),'-vf','scale=480:270,tile=4x3','-frames:v','1',str(w/f'review/cut-{n}.jpg')],check=True)
files=[dict(file=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size) for p in [out/'webops-factory-demo.mp4',out/'webops-factory-demo-mobile.mp4']]
m={'title':'WebOps Factory demo','durationSeconds':plan['duration'],'sourceRun':json.loads((w/'capture-source.json').read_text())['run'],'files':files,'audio':{'integratedLUFS':float(measure['input_i']),'truePeakDbTP':float(measure['input_tp']),'listening':'not_attested'},'reviewStatus':'REVIEW_INCOMPLETE','sourceNotes':'Actual browser interactions with retained live-run evidence and the real original/candidate example website. No simulated execution, captions or scene labels. Five supported defects repaired; additional crawl findings remain. Kujo bumper uses original logo and Departure Mono.','narration':{'provider':'ElevenLabs','model':'eleven_v4','voice':'eXpIbVcVbLo8ZJQDlDnl','receipts':'Editable source archive/media'},'limitations':['Perceptual audio listening not attested; no creative PASS claimed.','Film shows completed run records, not real-time agent execution.']}
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps(m,indent=2))
