import subprocess,numpy as np,json,sys
from pathlib import Path
p=sys.argv[1];out=Path(sys.argv[2]);out.parent.mkdir(parents=True,exist_ok=True)
a=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',p,'-vf','scale=96:54','-pix_fmt','gray','-f','rawvideo','-']),np.uint8).reshape(-1,54,96).astype(float)
d=np.abs(a[1:]-a[:-1]).mean(axis=(1,2));candidates=[]
for span in range(1,7):
 for i in range(1,len(a)-span):
  before=np.abs(a[i]-a[i-1]).mean();after=np.abs(a[i+span]-a[i+span-1]).mean();returning=np.abs(a[i+span]-a[i-1]).mean()
  if min(before,after)>10 and returning<min(before,after)*.25:candidates.append({'frame':i,'seconds':i/30,'spanFrames':span,'jump':round(before,2),'return':round(returning,2)})
flatGray=[int(i) for i,f in enumerate(a) if ((f>105)&(f<150)).mean()>.5]
black=[int(i) for i,f in enumerate(a) if f.mean()<5]
r={'file':p,'frames':len(a),'isolatedFlashCandidates':candidates,'grayStartupFrames':flatGray,'blackFrames':black,'blankWhiteFrames':[int(i) for i,f in enumerate(a) if f.mean()>230 and f.std()<1],'largestChanges':[{'frame':int(i+1),'seconds':round((i+1)/30,3),'meanPixelDifference':round(float(d[i]),2)} for i in np.argsort(d)[-15:][::-1]]};out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k] for k in ['frames','isolatedFlashCandidates','grayStartupFrames','blackFrames','blankWhiteFrames']}))
