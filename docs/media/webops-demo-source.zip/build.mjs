import fs from 'node:fs/promises';import path from 'node:path';import {createHash} from 'node:crypto';
import {renderProject} from './render.mjs';
const workspace=path.resolve('.runtime/demo');const plan=JSON.parse(await fs.readFile(path.join(workspace,'plan.json')));
const assets=[];for(const [id,file,kind] of [['intro','intro.mp4','video'],['floor','floor.mp4','video'],['review','review.mp4','video'],['outputs','outputs.mp4','video'],['kujo-logo','kujo-logo.svg','image'],['departure-mono','departure-mono.woff2','font'],['narration','narration.wav','audio'],['music','music.wav','audio']]){const data=await fs.readFile(path.join(workspace,'assets',file));assets.push({id,path:'assets/'+file,kind,sha256:createHash('sha256').update(data).digest('hex')});}
await fs.writeFile(path.join(workspace,'assets.json'),JSON.stringify(assets,null,2)+'\n');
const result=await renderProject({workspace,plan,assets,onProgress:e=>console.log(JSON.stringify(e))});await fs.writeFile(path.join(workspace,'result.json'),JSON.stringify(result,null,2)+'\n');
