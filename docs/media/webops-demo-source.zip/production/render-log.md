# Render record

The existing HyperFrames 0.9.40 composition passed lint and browser checks. After an interrupted orchestration session, the unchanged composition rendered locally at 1920 × 1080, 30 fps, for 46.5 seconds using two workers. The delivery render took 8 minutes 30.4 seconds on this busy host. No narration was regenerated during the resume.

The media files in docs/media are fast-start delivery derivatives of output/draft.mp4. Exact hashes, decode checks, audio measurements and full-frame flash scanning accompany the review.
