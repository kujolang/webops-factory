# Render record

The existing HyperFrames 0.9.40 composition passed lint and browser checks. After an interrupted orchestration session, the unchanged composition rendered locally at 1920 × 1080, 30 fps, for 46.5 seconds using two workers. The delivery render took 8 minutes 30.4 seconds on this busy host. No narration was regenerated during the resume.

The media files in docs/media are fast-start delivery derivatives of output/draft.mp4. Exact hashes, decode checks, audio measurements and full-frame flash scanning accompany the review.

## Closing revision

The user requested a benefits-first sentence before the CTA and corrected LANG pronunciation. One new Siren v4 closing cue was generated (170 input characters, 75 observed credits). Original cues remain unchanged. The new duration is 53.366667 seconds. The editable HyperFrames project was updated and passed fresh lint/browser checks. The delivery reuses original source footage and extends the static final bumper; the new soundtrack combines the original four cues and replacement closing. An initial packet-concat attempt had a tint/metadata mismatch and overlapping timestamps, so it was replaced by one constant-30-fps encode directly from original YUV footage with cloned final frames and explicit BT.709 metadata. The video was re-encoded; decoded-byte identity is not claimed. Exact timing checks and commands are retained in revision-v2/assembly.json. No new overlay text was added.
