# Asset rights

Music and Kujo logo reused from the existing authorized Publishing House demo. Departure Mono is reused with its SIL Open Font License, copied alongside it. Narration is original session copy generated using the existing Creator account for this product demonstration, subject to ElevenLabs terms. Acquisition is not perceptual approval.
