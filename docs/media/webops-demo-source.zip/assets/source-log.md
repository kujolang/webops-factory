# Sources

Siren narration: five bounded ElevenLabs v4 requests through the canonical Kujo VideoOps media runtime. Exact originals, normalized WAV files, hashes and provider usage receipts are under media/.

Music, logo and font: copied unchanged from publishing-house-factory/.runtime/demo-v3/assets. Music also imported through the local adapter for a provenance receipt. Font license copied from videoops-factory/assets.

All narration source text is planning/narration.json. Requests bind exact text hashes and fingerprints. Fresh subscription inspection confirmed included Creator allowance and no overage. No secret values are stored.

## Closing revision 2

One replacement Siren eleven_v4 closing cue was generated through the canonical VideoOps runtime as webops-bumper-002. TTS input: Koo-joe LANG dot A I, with LANG as in English language. The new benefits sentence names WebOps Factory. The first four cue originals, all video footage, music, logo and font were reused. Observed revision usage: 75 credits; monetary cost unknown. Exact original and normalized speech files and result receipt remain under media/webops-bumper-002. Listening is not attested.
