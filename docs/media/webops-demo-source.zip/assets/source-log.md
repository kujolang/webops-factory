# Sources

Siren narration: five bounded ElevenLabs v4 requests through the canonical Kujo VideoOps media runtime. Exact originals, normalized WAV files, hashes and provider usage receipts are under media/.

Music, logo and font: copied unchanged from publishing-house-factory/.runtime/demo-v3/assets. Music also imported through the local adapter for a provenance receipt. Font license copied from videoops-factory/assets.

All narration source text is planning/narration.json. Requests bind exact text hashes and fingerprints. Fresh subscription inspection confirmed included Creator allowance and no overage. No secret values are stored.
