import {chromium} from '../../node_modules/playwright/index.mjs';
import fs from 'node:fs';import {execFileSync} from 'node:child_process';
const w='.runtime/demo';const run=process.env.WEBOPS_DEMO_RUN;if(!run)throw Error('Explicit successful live run required');
const base='http://127.0.0.1:4383';const states=await (await fetch(base+'/api/runs')).json();const state=states.find(r=>r.id===run);if(state?.status!=='approval_required'||state.mode!=='live')throw Error('Run is not successful live evidence');
fs.mkdirSync(w+'/assets',{recursive:true});const plan=JSON.parse(fs.readFileSync(w+'/plan.json'));const browser=await chromium.launch({channel:'chrome',headless:true});
for(const scene of plan.scenes.filter(s=>s.assetId)){
 const page=await browser.newPage({viewport:{width:1600,height:900}});
 if(scene.id==='intro'){await page.goto(`${base}/artifact/${run}/before/index.html`);await page.locator('.button').hover();}
 else{await page.goto(base);await page.waitForSelector('.station');await page.locator('#picker').selectOption(run);await page.waitForFunction(id=>data?.state.id===id&&document.querySelector('#title').textContent.includes('Verified repairs'),run);await page.locator('[data-tab='+({floor:'floor',review:'repairs',outputs:'proof'}[scene.id])+']').click();if(scene.id==='review')await page.locator('[data-finding="2"]').click();if(scene.id==='review'||scene.id==='outputs')await page.locator('.tabs').evaluate(e=>e.scrollIntoView());}
 await page.evaluate(()=>document.fonts.ready);await page.waitForTimeout(800);
 const dir=w+'/frames/'+scene.id;fs.mkdirSync(dir,{recursive:true});const frames=[{t:0,bytes:await page.screenshot({type:'jpeg',quality:95})}];const cdp=await page.context().newCDPSession(page);const start=Date.now();
 cdp.on('Page.screencastFrame',e=>{const t=(e.metadata.timestamp*1000-start)/1000;if(t>=0&&t<scene.duration)frames.push({t,bytes:Buffer.from(e.data,'base64')});cdp.send('Page.screencastFrameAck',{sessionId:e.sessionId}).catch(()=>{});});await cdp.send('Page.startScreencast',{format:'jpeg',quality:95,maxWidth:1600,maxHeight:900,everyNthFrame:1});const at=async(t,fn)=>{await page.waitForTimeout(Math.max(0,t*1000-(Date.now()-start)));await fn()};
 if(scene.id==='intro'){await at(scene.duration*.4,()=>page.locator('.button').focus());await at(scene.duration*.72,()=>page.locator('.hero').evaluate(e=>e.scrollIntoView({behavior:'smooth',block:'start'})));}
 if(scene.id==='floor'){for(let i=0;i<6;i++)await at(.5+i*(scene.duration-1)/6,()=>page.locator(`[data-station="${i}"]`).click());}
 if(scene.id==='review'){await at(scene.duration*.58,()=>page.locator('[data-finding="3"]').click());}
 if(scene.id==='outputs'){await at(scene.duration*.35,()=>page.goto(`${base}/artifact/${run}/candidate/index.html`));await at(scene.duration*.64,()=>page.locator('.button').click());}
 await at(scene.duration,()=>cdp.send('Page.stopScreencast'));frames.sort((a,b)=>a.t-b.t);let list='';for(let i=0;i<frames.length;i++){fs.writeFileSync(dir+'/'+i+'.jpg',frames[i].bytes);list+=`file '${i}.jpg'\nduration ${Math.max(.001,(frames[i+1]?.t??scene.duration)-frames[i].t)}\n`;}list+=`file '${frames.length-1}.jpg'\n`;fs.writeFileSync(dir+'/concat.txt',list);
 execFileSync('ffmpeg',['-v','error','-y','-f','concat','-safe','0','-i',dir+'/concat.txt','-t',String(scene.duration),'-vf','fps=30,scale=1920:1080','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p',w+'/assets/'+scene.id+'.mp4']);console.log(JSON.stringify({scene:scene.id,frames:frames.length,duration:scene.duration,sourceRun:run}));await page.close();
}
await browser.close();fs.writeFileSync(w+'/capture-source.json',JSON.stringify({run,state,method:'Timestamped post-load CDP screencast; fixed scale; real interactions with retained completed run'},null,2));
