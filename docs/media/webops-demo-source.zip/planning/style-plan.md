# Visual direction

Let the site and factory speak. Fill the frame with actual browser footage. Keep the UI still long enough to read the relevant change, then make a deliberate interaction. No top labels, subtitles, fake cursor paths, simulated progress, or decorative transitions. Use hard cuts after the next shot is ready, with media scale fixed at one.

Carry the first-party Publishing House production’s monochrome styling and quiet music bed. The website may retain its own design. Use the K SVG and Departure Mono for a clean closing bumper. All bumper content must be visible on its first frame. Narration stays clear above the music. Do not trim speech to force the planned duration.
