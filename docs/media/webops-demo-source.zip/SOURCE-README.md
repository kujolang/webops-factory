# WebOps demo source

Open project/index.html with HyperFrames 0.9.40. The composition is 46.5 seconds, 1920×1080 at 30 fps. All production assets are local. To render from the project directory, run `npx hyperframes@0.9.40 render . --output demo.mp4 --fps 30 --quality delivery --workers 2 --strict`.

The four product clips are actual Chrome captures of a completed live run and the Northline Studio example. They show retained evidence, not real-time agent execution. The final bumper uses the Kujo K and Departure Mono. Narration is ElevenLabs Siren v4; original speech bytes and receipts are retained in media. Music is the existing first-party Kujo bed.

The film has no added captions or scene labels. Five targeted repairs do not establish that the entire site is free of issues. No site was deployed. See review for technical checks and the limits of perceptual review. Audio was measured, not auditioned.
