# WebOps demo source

Open project/index.html with HyperFrames 0.9.40. The composition is 53.366667 seconds, 1920×1080 at 30 fps. All production assets are local. To render from the project directory, run `npx hyperframes@0.9.40 render . --output demo.mp4 --fps 30 --quality delivery --workers 2 --strict`.

The four product clips are actual Chrome captures of a completed live run and the Northline Studio example. They show retained evidence, not real-time agent execution. The final bumper uses the Kujo K and Departure Mono. Narration is ElevenLabs Siren v4; original speech bytes and receipts are retained in media. Music is the existing first-party Kujo bed.

The film has no added captions or scene labels. Five targeted repairs do not establish that the entire site is free of issues. No site was deployed. See review for technical checks and the limits of perceptual review. Audio was measured, not auditioned.

Closing revision: the benefits-first sentence names WebOps Factory. TTS input uses Koo-joe LANG dot A I (LANG as in language); the readable transcript retains kujolang.ai. Pronunciation has not been attested by listening. Original four cues and all source footage are reused; the static bumper is extended. Video is re-encoded once at constant 30 fps with BT.709 metadata. See production/revision-v2/assembly.json.
