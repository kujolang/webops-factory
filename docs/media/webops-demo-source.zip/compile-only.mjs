import fs from 'node:fs/promises';import path from 'node:path';import {createHash} from 'node:crypto';import {compileTemplate} from './template.mjs';
const w=path.resolve('.runtime/demo');const plan=JSON.parse(await fs.readFile(path.join(w,'plan.json')));const assets=JSON.parse(await fs.readFile(path.join(w,'assets.json')));
for(const [i,a] of assets.entries()){a.sha256=createHash('sha256').update(await fs.readFile(path.join(w,a.path))).digest('hex');a.src='assets/asset-'+i+path.extname(a.path);await fs.copyFile(path.join(w,a.path),path.join(w,'production/hyperframes',a.src));}
for(const [name,html] of Object.entries(compileTemplate(plan,assets)))await fs.writeFile(path.join(w,'production/hyperframes',name),html);
await fs.writeFile(path.join(w,'assets.json'),JSON.stringify(assets,null,2)+'\n');
